<?php
// ============================================================
// MeuDia+ | Cadastro de usuário
// GET  -> mostra o formulário
// POST -> valida no servidor, salva no MySQL e vai para o login
// ============================================================
require "sessao.php";
require "conexao.php";

// Quem já está logado vai direto para o painel
if (isset($_SESSION['usuario_id'])) {
    header("Location: index.php");
    exit;
}

$erro      = null;
$nomeForm  = '';
$emailForm = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $nomeForm        = trim($_POST['nome'] ?? '');
    $emailForm       = mb_strtolower(trim($_POST['email'] ?? ''));
    $senha           = $_POST['senha'] ?? '';
    $confirmarSenha  = $_POST['confirmar_senha'] ?? '';

    if ($nomeForm === '' || $emailForm === '' || $senha === '' || $confirmarSenha === '') {
        $erro = 'campos';

    } elseif (mb_strlen($nomeForm) < 2 || mb_strlen($nomeForm) > 100) {
        $erro = 'nome_invalido';

    } elseif (!filter_var($emailForm, FILTER_VALIDATE_EMAIL) || strlen($emailForm) > 150) {
        $erro = 'email_invalido';

    } elseif (strlen($senha) < 6) {
        $erro = 'senha_curta';

    } elseif (strlen($senha) > 72) {
        // O bcrypt só considera os primeiros 72 caracteres
        $erro = 'senha_longa';

    } elseif ($senha !== $confirmarSenha) {
        $erro = 'senha_diferente';

    } else {
        // Verifica se o email já existe
        $stmt = $conexao->prepare("SELECT id FROM usuarios WHERE email = ?");
        $stmt->bind_param("s", $emailForm);
        $stmt->execute();
        $stmt->store_result();
        $existe = $stmt->num_rows > 0;
        $stmt->close();

        if ($existe) {
            $erro = 'email_existe';

        } else {
            // Salva o novo usuário com a senha criptografada
            $senhaHash = password_hash($senha, PASSWORD_DEFAULT);

            $stmt = $conexao->prepare("INSERT INTO usuarios (nome, email, senha) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $nomeForm, $emailForm, $senhaHash);

            if ($stmt->execute()) {
                $stmt->close();
                $conexao->close();
                header("Location: login.php?cadastro=sucesso");
                exit;
            }

            // 1062 = email duplicado (duas pessoas cadastrando ao mesmo tempo)
            $erro = ($stmt->errno === 1062) ? 'email_existe' : 'erro_servidor';
            $stmt->close();
        }
    }
}

$mensagensErro = [
    "campos"          => "Preencha todos os campos.",
    "nome_invalido"   => "O nome precisa ter entre 2 e 100 caracteres.",
    "email_invalido"  => "Digite um email válido.",
    "email_existe"    => "Este email já está cadastrado.",
    "senha_curta"     => "A senha precisa ter pelo menos 6 caracteres.",
    "senha_longa"     => "A senha pode ter no máximo 72 caracteres.",
    "senha_diferente" => "As senhas não coincidem.",
    "erro_servidor"   => "Não foi possível criar a conta agora. Tente novamente."
];

$olho = '
  <span class="password-toggle" onclick="togglePwd(this)">
    <svg class="icon-eye" viewBox="0 0 24 24">
      <path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7z"/>
      <circle cx="12" cy="12" r="3"/>
    </svg>
    <svg class="icon-eye-off" viewBox="0 0 24 24" style="display:none;">
      <path d="M17.94 17.94A10.94 10.94 0 0112 19c-7 0-11-7-11-7a21.8 21.8 0 015.06-6.06M9.9 4.24A10.94 10.94 0 0112 4c7 0 11 7 11 7a21.8 21.8 0 01-3.22 4.31M14.12 14.12a3 3 0 11-4.24-4.24"/>
      <line x1="1" y1="1" x2="23" y2="23"/>
    </svg>
  </span>';
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>MeuDia+ | Criar conta</title>
  <link rel="stylesheet" href="style.css">
</head>

<body>

  <div class="auth-page">
    <div class="auth-wrap">

      <div class="auth-left">
        <img class="logo-big" src="logo.png" alt="MeuDia+">

        <h1>Crie sua conta e comece a organizar seu dia</h1>

        <p>
          Nosso projeto tem o objetivo de ser um organizador para as pessoas
          organizarem em só um lugar suas tarefas, compromissos, finanças,
          compras, anotações e estudos para o seu dia a dia.
        </p>
      </div>

      <div class="auth-right">
        <h1>Criar conta</h1>

        <?php if ($erro && isset($mensagensErro[$erro])): ?>
          <div class="msg msg-erro"><?= htmlspecialchars($mensagensErro[$erro]) ?></div>
        <?php endif; ?>

        <form action="cadastro.php" method="POST">

          <div class="field-label">Nome</div>
          <input
            class="field-input"
            type="text"
            name="nome"
            placeholder="Digite seu nome"
            value="<?= htmlspecialchars($nomeForm) ?>"
            maxlength="100"
            autocomplete="name"
            required
          >

          <div class="field-label">Email</div>
          <input
            class="field-input"
            type="email"
            name="email"
            placeholder="Digite seu email"
            value="<?= htmlspecialchars($emailForm) ?>"
            maxlength="150"
            autocomplete="email"
            required
          >

          <div class="field-label">Senha</div>
          <div class="password-wrap">
            <input
              class="field-input"
              type="password"
              name="senha"
              placeholder="Crie uma senha (mín. 6 caracteres)"
              minlength="6"
              maxlength="72"
              autocomplete="new-password"
              required
            >
            <?= $olho ?>
          </div>

          <div class="field-label">Confirmar senha</div>
          <div class="password-wrap">
            <input
              class="field-input"
              type="password"
              name="confirmar_senha"
              placeholder="Repita a senha"
              minlength="6"
              maxlength="72"
              autocomplete="new-password"
              required
            >
            <?= $olho ?>
          </div>

          <button class="auth-btn" type="submit">
            CADASTRAR
          </button>

        </form>

        <div class="auth-switch">
          Já tem conta?
          <a href="login.php">Entrar</a>
        </div>
      </div>

    </div>
  </div>

  <script src="auth.js"></script>
</body>
</html>
