<?php
// ============================================================
// MeuDia+ | Alterar senha (usuário logado)
// Recebe JSON: { "atual": "...", "nova": "..." }
// ============================================================
require "sessao.php";
header("Content-Type: application/json; charset=utf-8");

function responder(int $codigo, bool $ok, string $mensagem = ''): void {
    http_response_code($codigo);
    echo json_encode(["ok" => $ok, "mensagem" => $mensagem]);
    exit;
}

if (!isset($_SESSION['usuario_id'])) {
    responder(401, false, "Sessão expirada.");
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    responder(405, false, "Método inválido.");
}

if (stripos($_SERVER['CONTENT_TYPE'] ?? '', 'application/json') !== 0) {
    responder(415, false, "Requisição inválida.");
}

$entrada = json_decode(file_get_contents("php://input"), true);
$atual   = (string) ($entrada['atual'] ?? '');
$nova    = (string) ($entrada['nova'] ?? '');

if ($atual === '' || $nova === '') {
    responder(400, false, "Preencha todos os campos.");
}

if (strlen($nova) < 6) {
    responder(400, false, "A nova senha precisa ter pelo menos 6 caracteres.");
}

if (strlen($nova) > 72) {
    responder(400, false, "A nova senha pode ter no máximo 72 caracteres.");
}

require "conexao.php";

$usuarioId = (int) $_SESSION['usuario_id'];

$stmt = $conexao->prepare("SELECT senha FROM usuarios WHERE id = ?");
$stmt->bind_param("i", $usuarioId);
$stmt->execute();
$usuario = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$usuario || !password_verify($atual, $usuario['senha'])) {
    responder(400, false, "A senha atual está incorreta.");
}

$novoHash = password_hash($nova, PASSWORD_DEFAULT);

$stmt = $conexao->prepare("UPDATE usuarios SET senha = ? WHERE id = ?");
$stmt->bind_param("si", $novoHash, $usuarioId);
$ok = $stmt->execute();
$stmt->close();
$conexao->close();

if (!$ok) {
    responder(500, false, "Não foi possível alterar a senha agora.");
}

session_regenerate_id(true);
responder(200, true, "Senha alterada.");
