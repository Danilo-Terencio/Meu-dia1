<?php
// ============================================================
// MeuDia+ | API de dados do usuário
// Salva/atualiza os dados SEMPRE do usuário logado (sessão)
// ============================================================
require "sessao.php";
header("Content-Type: application/json; charset=utf-8");

if (!isset($_SESSION['usuario_id'])) {
    http_response_code(401);
    echo json_encode(["ok" => false, "erro" => "nao_logado"]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["ok" => false, "erro" => "metodo"]);
    exit;
}

// Só aceita JSON (formulários de outros sites não conseguem enviar isso)
if (stripos($_SERVER['CONTENT_TYPE'] ?? '', 'application/json') !== 0) {
    http_response_code(415);
    echo json_encode(["ok" => false, "erro" => "tipo_invalido"]);
    exit;
}

require "conexao.php";

$entrada = json_decode(file_get_contents("php://input"), true);
$chave   = $entrada['chave'] ?? '';
$valor   = $entrada['valor'] ?? null;

// Só aceita as chaves que o site usa
$permitidas = [
    "tarefas", "agenda", "notas", "gastos", "compras", "estudos", "trabalhos",
    "renda", "nome", "cidade", "profissao", "objetivo", "sobre", "tema"
];

if (!is_string($chave) || !in_array($chave, $permitidas, true)) {
    http_response_code(400);
    echo json_encode(["ok" => false, "erro" => "chave_invalida"]);
    exit;
}

$json = json_encode($valor, JSON_UNESCAPED_UNICODE);

if ($json === false || strlen($json) > 1000000) {
    http_response_code(400);
    echo json_encode(["ok" => false, "erro" => "valor_invalido"]);
    exit;
}

$usuarioId = (int) $_SESSION['usuario_id'];

$stmt = $conexao->prepare(
    "INSERT INTO dados_usuario (usuario_id, chave, valor) VALUES (?, ?, ?)
     ON DUPLICATE KEY UPDATE valor = VALUES(valor)"
);
$stmt->bind_param("iss", $usuarioId, $chave, $json);
$ok = $stmt->execute();
$stmt->close();
$conexao->close();

if (!$ok) {
    http_response_code(500);
}

echo json_encode(["ok" => $ok]);
