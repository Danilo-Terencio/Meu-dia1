<?php
// MeuDia+ | Painel principal — acesso somente para quem está logado
require "sessao.php";

if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit;
}

// Carrega SOMENTE os dados do usuário que está logado
require "conexao.php";

$dadosUsuario = [];
$stmtDados = $conexao->prepare("SELECT chave, valor FROM dados_usuario WHERE usuario_id = ?");
$stmtDados->bind_param("i", $_SESSION['usuario_id']);
$stmtDados->execute();
$resDados = $stmtDados->get_result();
while ($linha = $resDados->fetch_assoc()) {
    $dadosUsuario[$linha['chave']] = json_decode($linha['valor'], true);
}
$stmtDados->close();
$conexao->close();

// Evita o navegador mostrar uma versão antiga dos arquivos
$vCss = filemtime(__DIR__ . '/painel.css');
$vJs  = filemtime(__DIR__ . '/painel.js');
$flags = JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT;
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>MeuDia+ | Organize sua vida</title>
<link rel="stylesheet" href="painel.css?v=<?= $vCss ?>">
<script>
window.MEUDIA = {
    dados: <?= json_encode($dadosUsuario ?: new stdClass(), $flags) ?>,
    nomeLogin: <?= json_encode($_SESSION['usuario_nome'], $flags) ?>
};
</script>
</head>

<body>
<script>
(function(){
    var t = window.MEUDIA.dados.tema;
    var escuro = t ? t === "escuro"
        : (window.matchMedia && matchMedia("(prefers-color-scheme: dark)").matches);
    if (escuro) document.body.classList.add("dark");
})();
</script>

<header>
    <div class="logo">
        <img src="logo.png" alt="Logo MeuDia+" style="height:45px;width:auto;">
        <div>
            <h1>MeuDia+</h1>
            <p>Organize sua vida em um só lugar</p>
        </div>
    </div>

    <nav>
        <button class="active" onclick="abrirPagina('inicio',this)">🏠 Início</button>
        <button onclick="abrirPagina('tarefas',this)">✅ Tarefas</button>
        <button onclick="abrirPagina('agenda',this)">📅 Agenda</button>
        <button onclick="abrirPagina('notas',this)">📝 Notas</button>
        <button onclick="abrirPagina('financas',this)">💰 Finanças</button>
        <button onclick="abrirPagina('compras',this)">🛒 Compras</button>
        <button onclick="abrirPagina('estudos',this)">📚 Estudos</button>
        <button onclick="abrirPagina('conta',this)">⚙️ Conta</button>
        <button id="btnTema" onclick="alternarTema()" title="Alternar tema claro/escuro">🌙</button>
        <button onclick="window.location.href='logout.php'">🚪 Sair</button>
    </nav>
</header>

<div class="container">

<!-- INÍCIO -->
<section id="inicio" class="page active">

    <div class="hero">
        <h2 id="saudacao">Olá!</h2>

        <p>
            Tenha suas principais atividades, compromissos,
            anotações e finanças organizados em um só lugar.
        </p>

        <div class="data-atual" id="dataAtual"></div>

        <div class="search">
            <input id="buscaGeral"
                   placeholder="🔎 Pesquise tarefas, notas, compras...">
            <button onclick="buscarTudo()">Pesquisar</button>
        </div>
    </div>

    <div class="grid">

        <div class="card">
            <div class="card-icon">✅</div>
            <h3>Tarefas</h3>
            <p id="totalTarefas" class="stat">0</p>
            <p>tarefas cadastradas</p>
        </div>

        <div class="card">
            <div class="card-icon">📅</div>
            <h3>Agenda</h3>
            <p id="totalAgenda" class="stat">0</p>
            <p>compromissos</p>
        </div>

        <div class="card">
            <div class="card-icon">🛒</div>
            <h3>Compras</h3>
            <p id="totalCompras" class="stat">0</p>
            <p>itens na lista</p>
        </div>

        <div class="card">
            <div class="card-icon">📝</div>
            <h3>Anotações</h3>
            <p id="totalNotas" class="stat">0</p>
            <p>anotações salvas</p>
        </div>

    </div>

    <div class="dashboard-grid">

        <div class="box">
            <h2>📌 Próximas tarefas</h2>
            <div id="resumoTarefas"></div>
        </div>

        <div class="box">
            <h2>💰 Resumo financeiro</h2>

            <p>Renda:</p>
            <strong id="dashRenda">R$ 0,00</strong>

            <br><br>

            <p>Gastos:</p>
            <strong id="dashGastos">R$ 0,00</strong>

            <br><br>

            <p>Saldo:</p>
            <strong id="dashSaldo">R$ 0,00</strong>
        </div>

    </div>

</section>

<!-- TAREFAS -->
<section id="tarefas" class="page">

    <div class="titulo">
        <h2>✅ Minhas tarefas</h2>
        <p>Organize tudo o que precisa fazer.</p>
    </div>

    <div class="box">
        <div class="form-grid">

            <div>
                <label>Tarefa</label>
                <input id="tarefaTexto"
                       placeholder="Ex.: Fazer trabalho da escola">
            </div>

            <div>
                <label>Prioridade</label>
                <select id="tarefaPrioridade">
                    <option>Normal</option>
                    <option>Importante</option>
                    <option>Urgente</option>
                </select>
            </div>
            <div>
                <label>Prazo (opcional)</label>
                <input id="tarefaPrazo" type="date">
            </div>

        </div>

        <button class="btn"
                style="margin-top:15px"
                onclick="adicionarTarefa()">
            ➕ Adicionar tarefa
        </button>
    </div>

    <div class="box">
        <h2>Lista</h2>
        <div id="listaTarefas"></div>
    </div>

</section>

<!-- AGENDA -->
<section id="agenda" class="page">

    <div class="titulo">
        <h2>📅 Minha agenda</h2>
        <p>Cadastre seus compromissos.</p>
    </div>

    <div class="box">
        <div class="form-grid">

            <div>
                <label>Compromisso</label>
                <input id="eventoNome"
                       placeholder="Ex.: Consulta médica">
            </div>

            <div>
                <label>Data</label>
                <input id="eventoData" type="date">
            </div>

            <div>
                <label>Horário</label>
                <input id="eventoHora" type="time">
            </div>

            <div>
                <label>Local</label>
                <input id="eventoLocal"
                       placeholder="Ex.: Centro">
            </div>

        </div>

        <button class="btn"
                style="margin-top:15px"
                onclick="adicionarEvento()">
            📅 Adicionar compromisso
        </button>
    </div>

    <div class="box">
        <h2>Meus compromissos</h2>
        <div id="listaAgenda"></div>
    </div>

</section>

<!-- NOTAS -->
<section id="notas" class="page">

    <div class="titulo">
        <h2>📝 Minhas anotações</h2>
        <p>Guarde ideias, informações e lembretes.</p>
    </div>

    <div class="box">

        <label>Título</label>
        <input id="notaTitulo"
               placeholder="Título da anotação">

        <br><br>

        <label>Texto</label>
        <textarea id="notaTexto"
                  placeholder="Escreva aqui..."></textarea>

        <button class="btn"
                style="margin-top:15px"
                onclick="adicionarNota()">
            💾 Salvar anotação
        </button>

    </div>

    <div class="box">
        <h2>Anotações salvas</h2>
        <div id="listaNotas"></div>
    </div>

</section>

<!-- FINANÇAS -->
<section id="financas" class="page">

    <div class="titulo">
        <h2>💰 Minhas finanças</h2>
        <p>Controle sua renda e seus gastos.</p>
    </div>

    <div class="finance-grid">

        <div class="finance-card">
            <h3>💵 Renda</h3>
            <div id="rendaValor" class="finance-value entrada">
                R$ 0,00
            </div>
        </div>

        <div class="finance-card">
            <h3>📉 Gastos</h3>
            <div id="gastosValor" class="finance-value saida">
                R$ 0,00
            </div>
        </div>

        <div class="finance-card">
            <h3>💰 Saldo</h3>
            <div id="saldoValor" class="finance-value saldo">
                R$ 0,00
            </div>
        </div>

    </div>

    <div class="box" style="margin-top:20px">

        <h2>💵 Minha renda</h2>

        <div class="form-grid">

            <div>
                <label>Valor da renda</label>
                <input id="rendaInput"
                       type="number"
                       step="0.01"
                       placeholder="Ex.: 2500">
            </div>

            <div>
                <label>Fonte</label>
                <input id="rendaFonte"
                       placeholder="Ex.: Salário">
            </div>

        </div>

        <button class="btn"
                style="margin-top:15px"
                onclick="salvarRenda()">
            💾 Salvar renda
        </button>

    </div>

    <div class="box">

        <h2>➕ Adicionar gasto</h2>

        <div class="form-grid">

            <div>
                <label>Descrição</label>
                <input id="gastoDescricao"
                       placeholder="Ex.: Mercado">
            </div>

            <div>
                <label>Valor</label>
                <input id="gastoValor"
                       type="number"
                       step="0.01"
                       placeholder="Ex.: 100">
            </div>

            <div>
                <label>Categoria</label>
                <select id="gastoCategoria">
                    <option>Alimentação</option>
                    <option>Transporte</option>
                    <option>Casa</option>
                    <option>Estudos</option>
                    <option>Lazer</option>
                    <option>Compras</option>
                    <option>Outros</option>
                </select>
            </div>

        </div>

        <button class="btn"
                style="margin-top:15px"
                onclick="adicionarGasto()">
            ➕ Adicionar gasto
        </button>

    </div>

    <div class="box">
        <h2>📊 Gastos por categoria</h2>
        <div id="graficoGastos"></div>
    </div>

    <div class="box">
        <h2>📋 Histórico de gastos</h2>
        <div id="listaGastos"></div>
    </div>

</section>

<!-- COMPRAS -->
<section id="compras" class="page">

    <div class="titulo">
        <h2>🛒 Lista de compras</h2>
        <p>Não esqueça o que precisa comprar.</p>
    </div>

    <div class="box">
        <div class="search">
            <input id="produtoInput"
                   placeholder="Ex.: Arroz, leite, pão...">
            <button onclick="adicionarCompra()">Adicionar</button>
        </div>
    </div>

    <div class="box">
        <h2>Minha lista</h2>
        <div id="listaCompras"></div>
    </div>

</section>

<!-- ESTUDOS -->
<section id="estudos" class="page">

    <div class="titulo">
        <h2>📚 Estudos</h2>
        <p>Organize suas matérias e atividades escolares.</p>
    </div>

    <div class="box">

        <div class="form-grid">

            <div>
                <label>Matéria</label>
                <input id="materia"
                       placeholder="Ex.: Matemática">
            </div>

            <div>
                <label>Atividade</label>
                <input id="atividade"
                       placeholder="Ex.: Fazer exercícios">
            </div>

            <div>
                <label>Data de entrega</label>
                <input id="dataEstudo" type="date">
            </div>

        </div>

        <button class="btn"
                style="margin-top:15px"
                onclick="adicionarEstudo()">
            📚 Adicionar atividade
        </button>

    </div>

    <div class="box">
        <h2>Atividades</h2>
        <div id="listaEstudos"></div>
    </div>

</section>

<!-- TRABALHO -->
<section id="trabalho" class="page">

    <div class="titulo">
        <h2>💼 Trabalho</h2>
        <p>Organize suas atividades profissionais.</p>
    </div>

    <div class="box">

        <div class="form-grid">

            <div>
                <label>Tarefa profissional</label>
                <input id="trabalhoTexto"
                       placeholder="Ex.: Entregar relatório">
            </div>

            <div>
                <label>Prazo</label>
                <input id="trabalhoData" type="date">
            </div>

            <div class="full">
                <label>Observação</label>
                <textarea id="trabalhoObs"
                          placeholder="Informações adicionais..."></textarea>
            </div>

        </div>

        <button class="btn"
                style="margin-top:15px"
                onclick="adicionarTrabalho()">
            💼 Adicionar atividade
        </button>

    </div>

    <div class="box">
        <h2>Atividades profissionais</h2>
        <div id="listaTrabalho"></div>
    </div>

</section>

<!-- EMERGÊNCIA -->
<section id="emergencia" class="page">

    <div class="alerta">
        <h2>🚨 Emergência</h2>
        <p>
            Em uma situação de emergência, procure um local seguro
            e entre em contato com o serviço adequado.
        </p>
    </div>

    <div class="emergencias">

        <div class="emergencia">
            <div class="emergencia-icon">🚓</div>
            <h3>Polícia</h3>
            <p>Emergências policiais.</p>
            <a class="ligar" href="tel:190">Ligar 190</a>
        </div>

        <div class="emergencia">
            <div class="emergencia-icon">🚑</div>
            <h3>SAMU</h3>
            <p>Atendimento médico de urgência.</p>
            <a class="ligar" href="tel:192">Ligar 192</a>
        </div>

        <div class="emergencia">
            <div class="emergencia-icon">🚒</div>
            <h3>Bombeiros</h3>
            <p>Incêndios e situações de emergência.</p>
            <a class="ligar" href="tel:193">Ligar 193</a>
        </div>

        <div class="emergencia">
            <div class="emergencia-icon">🚔</div>
            <h3>PRF</h3>
            <p>Emergências em rodovias federais.</p>
            <a class="ligar" href="tel:191">Ligar 191</a>
        </div>

        <div class="emergencia">
            <div class="emergencia-icon">🛡️</div>
            <h3>Defesa Civil</h3>
            <p>Desastres e situações de risco.</p>
            <a class="ligar" href="tel:199">Ligar 199</a>
        </div>

        <div class="emergencia">
            <div class="emergencia-icon">🚨</div>
            <h3>Disque-Denúncia</h3>
            <p>Procure o serviço disponível na sua região.</p>
        </div>

    </div>

</section>

<!-- PERFIL -->
<section id="perfil" class="page">

    <div class="titulo">
        <h2>👤 Meu perfil</h2>
        <p>Configure suas informações.</p>
    </div>

    <div class="box">

        <div class="form-grid">

            <div>
                <label>Nome</label>
                <input id="perfilNome"
                       placeholder="Seu nome">
            </div>

            <div>
                <label>Cidade</label>
                <input id="perfilCidade"
                       placeholder="Sua cidade">
            </div>

            <div>
                <label>Profissão</label>
                <input id="perfilProfissao"
                       placeholder="Sua profissão">
            </div>

            <div>
                <label>Objetivo</label>
                <input id="perfilObjetivo"
                       placeholder="Ex.: Organizar minha rotina">
            </div>

            <div class="full">
                <label>Sobre você</label>
                <textarea id="perfilSobre"
                          placeholder="Escreva algumas informações..."></textarea>
            </div>

        </div>

        <button class="btn"
                style="margin-top:15px"
                onclick="salvarPerfil()">
            💾 Salvar perfil
        </button>

    </div>

</section>

<!-- RESULTADOS -->
<!-- CONTA -->
<section id="conta" class="page">

    <div class="titulo">
        <h2>⚙️ Minha conta</h2>
        <p>Aparência, segurança e seus dados.</p>
    </div>

    <div class="box">
        <h2>🎨 Aparência</h2>
        <p class="descricao">Escolha entre o tema claro e o tema escuro.</p>
        <button class="btn" onclick="alternarTema()">🌙 Alternar tema</button>
    </div>

    <div class="box">
        <h2>🔒 Alterar senha</h2>
        <div class="form-grid">
            <div class="full">
                <label>Senha atual</label>
                <input id="senhaAtual" type="password" autocomplete="current-password">
            </div>
            <div>
                <label>Nova senha</label>
                <input id="senhaNova" type="password" minlength="6" maxlength="72" autocomplete="new-password" placeholder="Mínimo de 6 caracteres">
            </div>
            <div>
                <label>Confirmar nova senha</label>
                <input id="senhaConfirmar" type="password" minlength="6" maxlength="72" autocomplete="new-password">
            </div>
        </div>
        <button class="btn" style="margin-top:15px" onclick="trocarSenha()">🔑 Alterar senha</button>
    </div>

    <div class="box">
        <h2>⬇️ Exportar meus dados</h2>
        <p class="descricao">
            Baixe tarefas, agenda, anotações, gastos e compras em um arquivo CSV
            (abre no Excel ou no Google Planilhas).
        </p>
        <button class="btn" onclick="exportarCSV()">⬇️ Baixar CSV</button>
    </div>

</section>

<section id="resultados" class="page">

    <div class="titulo">
        <h2>🔎 Resultados da busca</h2>
        <p>Itens encontrados no seu MeuDia+.</p>
    </div>

    <div class="box">
        <div id="listaResultados"></div>
    </div>

</section>

</div>

<footer>
    <strong>MeuDia+</strong>
    <br><br>
    Organize tarefas, estudos, trabalho e sua vida financeira
    em um só lugar.
    <br><br>
    ©️ 2026 MeuDia+
</footer>

<script src="painel.js?v=<?= $vJs ?>"></script>

</body>
</html>