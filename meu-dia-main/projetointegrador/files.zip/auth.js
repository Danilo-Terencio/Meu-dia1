// MeuDia+ | Mostrar/esconder senha (login e cadastro)
function togglePwd(el) {
  const wrap = el.closest('.password-wrap');
  const input = wrap.querySelector('input');
  const eye = el.querySelector('.icon-eye');
  const eyeOff = el.querySelector('.icon-eye-off');

  if (input.type === 'password') {
    input.type = 'text';
    eye.style.display = 'none';
    eyeOff.style.display = 'inline';
  } else {
    input.type = 'password';
    eye.style.display = 'inline';
    eyeOff.style.display = 'none';
  }
}
