<?php
// ============================================================
// MeuDia+ | Login
// GET  -> mostra o formulário
// POST -> confere email/senha, limita tentativas erradas e abre a sessão
// ============================================================
require "sessao.php";
require "conexao.php";

// Quem já está logado vai direto para o painel
if (isset($_SESSION['usuario_id'])) {
    header("Location: index.php");
    exit;
}

const MAX_TENTATIVAS_EMAIL = 5;   // erros por email em 10 minutos
const MAX_TENTATIVAS_IP    = 20;  // erros por IP em 10 minutos

function contarTentativas(mysqli $c, string $campo, string $valor): int {
    // $campo vem sempre de um texto fixo abaixo ('email' ou 'ip')
    $stmt = @$c->prepare(
        "SELECT COUNT(*) FROM login_tentativas
         WHERE $campo = ? AND criado_em > (NOW() - INTERVAL 10 MINUTE)"
    );
    if (!$stmt) return 0;
    $stmt->bind_param("s", $valor);
    $stmt->execute();
    $stmt->bind_result($n);
    $stmt->fetch();
    $stmt->close();
    return (int) $n;
}

function registrarFalha(mysqli $c, string $email, string $ip): void {
    @$c->query("DELETE FROM login_tentativas WHERE criado_em < (NOW() - INTERVAL 1 DAY)");
    $stmt = @$c->prepare("INSERT INTO login_tentativas (email, ip) VALUES (?, ?)");
    if (!$stmt) return;
    $stmt->bind_param("ss", $email, $ip);
    $stmt->execute();
    $stmt->close();
}

function limparFalhas(mysqli $c, string $email): void {
    $stmt = @$c->prepare("DELETE FROM login_tentativas WHERE email = ?");
    if (!$stmt) return;
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->close();
}

$erro      = null;
$sucesso   = null;
$emailForm = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $emailForm = mb_strtolower(trim($_POST['email'] ?? ''));
    $senha     = $_POST['senha'] ?? '';
    $ip        = $_SERVER['REMOTE_ADDR'] ?? '';

    if ($emailForm === '' || $senha === '') {
        $erro = 'campos';

    } elseif (
        contarTentativas($conexao, 'email', $emailForm) >= MAX_TENTATIVAS_EMAIL ||
        contarTentativas($conexao, 'ip', $ip) >= MAX_TENTATIVAS_IP
    ) {
        $erro = 'bloqueado';

    } else {
        $stmt = $conexao->prepare("SELECT id, nome, senha FROM usuarios WHERE email = ?");
        $stmt->bind_param("s", $emailForm);
        $stmt->execute();
        $usuario = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$usuario || !password_verify($senha, $usuario['senha'])) {
            registrarFalha($conexao, $emailForm, $ip);
            $erro = 'invalido';

        } else {
            limparFalhas($conexao, $emailForm);

            // Gera um novo ID de sessão ao entrar (evita fixação de sessão)
            session_regenerate_id(true);
            $_SESSION['usuario_id']   = (int) $usuario['id'];
            $_SESSION['usuario_nome'] = $usuario['nome'];

            $conexao->close();
            header("Location: index.php");
            exit;
        }
    }

} elseif (($_GET['cadastro'] ?? '') === 'sucesso') {
    $sucesso = "Conta criada com sucesso! Faça login para continuar.";
}

$mensagensErro = [
    "campos"    => "Preencha email e senha.",
    "invalido"  => "Email ou senha incorretos.",
    "bloqueado" => "Muitas tentativas incorretas. Aguarde 10 minutos e tente novamente."
];
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>MeuDia+ | Entrar</title>
  <link rel="stylesheet" href="style.css">
</head>

<body>

  <div class="auth-page">
    <div class="auth-wrap">

      <div class="auth-left">
        <img class="logo-big" src="logo.png" alt="MeuDia+">

        <h1>Acesse sua conta para continuar</h1>

        <p>
          Nosso projeto tem o objetivo de ser um organizador para as pessoas
          organizarem em só um lugar suas tarefas, compromissos, finanças,
          compras, anotações e estudos para o seu dia a dia.
        </p>
      </div>

      <div class="auth-right">
        <h1>Acesse sua conta</h1>

        <?php if ($sucesso): ?>
          <div class="msg msg-sucesso"><?= htmlspecialchars($sucesso) ?></div>
        <?php endif; ?>

        <?php if ($erro && isset($mensagensErro[$erro])): ?>
          <div class="msg msg-erro"><?= htmlspecialchars($mensagensErro[$erro]) ?></div>
        <?php endif; ?>

        <form action="login.php" method="POST">

          <div class="field-label">Email</div>
          <input
            class="field-input"
            type="email"
            name="email"
            placeholder="Digite seu email"
            value="<?= htmlspecialchars($emailForm) ?>"
            autocomplete="email"
            required
          >

          <div class="field-label">Senha</div>

          <div class="password-wrap">
            <input
              class="field-input"
              type="password"
              name="senha"
              placeholder="Digite sua senha"
              autocomplete="current-password"
              required
            >

            <span class="password-toggle" onclick="togglePwd(this)">
              <svg class="icon-eye" viewBox="0 0 24 24">
                <path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7z"/>
                <circle cx="12" cy="12" r="3"/>
              </svg>

              <svg class="icon-eye-off" viewBox="0 0 24 24" style="display:none;">
                <path d="M17.94 17.94A10.94 10.94 0 0112 19c-7 0-11-7-11-7a21.8 21.8 0 015.06-6.06M9.9 4.24A10.94 10.94 0 0112 4c7 0 11 7 11 7a21.8 21.8 0 01-3.22 4.31M14.12 14.12a3 3 0 11-4.24-4.24"/>
                <line x1="1" y1="1" x2="23" y2="23"/>
              </svg>
            </span>
          </div>

          <button class="auth-btn" type="submit">
            ENTRAR
          </button>

        </form>

        <div class="auth-switch">
          Ainda não tem conta?
          <a href="cadastro.php">Cadastre-se</a>
        </div>
      </div>

    </div>
  </div>

  <script src="auth.js"></script>
</body>
</html>
