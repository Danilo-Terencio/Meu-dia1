<?php
// MeuDia+ | Conexão com o banco de dados MySQL
//
// No XAMPP (seu computador) pode ficar assim.
// Ao publicar em uma hospedagem, troque pelos dados que ela fornecer
// e use um usuário do banco criado só para este site (nunca o "root").

$host  = "localhost";
$user  = "root";
$senha = "";
$banco = "meudia_db";

mysqli_report(MYSQLI_REPORT_OFF);

$conexao = @new mysqli($host, $user, $senha, $banco);

if ($conexao->connect_errno) {
    // O detalhe técnico vai só para o log do servidor, o visitante não vê
    error_log("MeuDia+ | Erro de conexão MySQL: " . $conexao->connect_error);
    http_response_code(500);
    die("Não foi possível acessar o sistema agora. Tente novamente em alguns minutos.");
}

$conexao->set_charset("utf8mb4");
